a=int(input("enter  a number"))
if a>0:
  print("a is positive ")
elif a<0:
  print(" a is negative value")
else:
  print(" a is zero")