a=int(input('enter a number'))
for i in range(a,0,-1):
    print(i*'*')