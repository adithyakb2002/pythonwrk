a="count number of vowels in a string ii"
b=a.count('a')
c=a.count('e')
t=a.count('i')
d=a.count('o')
e=a.count('u')
print(b+c+d+e+t)
print("a =",a.count('a'),"e =",a.count('e'),"i =",a.count('i'),"o =",a.count('o'),"u =",a.count('u'))

