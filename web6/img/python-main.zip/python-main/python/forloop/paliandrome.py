






# 
# a=list(input("enter a list"))
# b=[]
# for i in a:
#     if i in range(i,a+1,2):
#         print(b.append())
       






# a=[1,2,3,4,5]
# b=[]
# target=6
# for i in  a:
#     for j in range(i+1,len(a)):
#         if a[i]+a[j]==target:
            
#             print("True")
#         else:
#             print("false")








# # li='ABABAABBBBAB'
# a=li.count('A')
# b=li.count('B')
# if a==b:
#     print("balanced")
# else:
#     print("unbalanced")



# 191
# a='000000000010101001010111111'
# print(a.count('1'))



# s=input("enter a input")
# s='{}[]()'
# s.split()
# if s=='[]':
#     print("true")
# elif s=='{}':
#     print("true")
# elif s=='()':
#     print("true")
# else:
#     print("false")







#  414
# a=list(input("enter a list"))
# a.remove(max(a)) 
# print(a)    




# s='remove a element in a string'
# b=s.split()
# print(b.reverse())
# print(s[::-1])




# s="hello"
# b="aeiou"
# c=''
# for i in s:
#     for j in b:
#       if i in j:
        


# 1913


# 

# a='a man a plan a canal panama'
# for i in a:
#     if (i==" "):
#         continue
#         if a[::-1]:
#             print(a)


# a=[1,2,2,3,3,3,2,4]
# b=[]
# for i in a:
#     if a.count(i)==1:
#         c=b.append(i)
#         print( c)



# a=['flower',"flow","flight"]
# for i in a:
#     if 
# s="Hello"
# # s.lower()
# print(s.lower())