# a=10
# b=2
# n=1
# try:
#   c=a/b
#   print(n)
# except Exception:
#   print("exception")
# except NameError:
#          print("name error")


# # print(c)
# else:
#     print("else part")
# finally:
#     print("finally part")

