#check the string is balanced or unbalanced without count
# li='ABABAABBBBAB'
# c=0
# d=0
# for i in li:
#     # print(i)
#     if i=='A':
#         c+=1  
#     if i=="B":
#        d+=1
# if c==d:
#     print("balanced")
# else:
#     print("unbalanced")


#check the string is balanced or unbalanced with count

# li='ABABAABBBBAB'
# a=li.count('A')
# b=li.count('B')
# if a==b:
#     print("balanced")
# else:
#     print("unbalanced")

# a=[2,1,3,4]
# c=[]
# b=max(a)
# d=min(a)
# e=max(a)-1
# f=min(a)+1
# c.insert(1,d)
# c.insert(1,b)
# c.insert(1,e)
# c.insert(1,f)

# print(c)

# a=[2,3,4,5,7,1]
# b=[]
# target=6
# if a[0]+a[1]==target:
#     b.append(0)
#     b.append(1)
#     print(b)
# elif a[1]+a[2]==target:
#     b.append(2)
#     b.append(1)
#     print(b)
# elif a[0]+a[2]==target:
#     b.append(0)
#     b.append(2)
#     print(b)




# a=[2,3,4,5,7,1]
# b=[]
# target=6
# for i in range(0,len(a)):
#     for j in range(i+1,len(a)):
#         if a[i]+a[j]==target:
#             b.append(a[i])
#             b.append(a[j])
#             print(b)

    
                                                                                                                                                                                           
a="lorem"
print(a[:-1])


    

