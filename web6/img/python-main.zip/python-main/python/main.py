# birth_year=int(input("enter your birth year"))
# if birth_year>=2000:
#     print("20's kid")
# else:
#     print("90's kid")
# a=str(input("enter your password"))
# if len(a)>=8:
#        for i in a:
#               if i.isdigit():
#                      num=True
#               if i.isalnum():
#                      symbol=True
a=int(input('enter your mark'))
if a>59:
    if a>=90:
        print('A')
    elif a>=80:
        print("B")
    elif a>=70:
        print("C") 
   
    elif a>=60:
        print('D')
else:
    print("failed")

       

             

    
   
     



