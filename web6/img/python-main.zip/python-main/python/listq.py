# my_list=[1,1.5,'apple',[1,2,3],True]
# print(my_list)

# 2
# l1=[1,2,3,4,5,6,7]
# sub=l1[1:4]
# print(sub)

# 3
# list1=[1,2,3]
# list2=[4,5,5]
# combined_list=list1+list2
# print(combined_list)

# 4
# fruits=['apple','banana','cherry']
# fruits.append('kiwi')
# print(fruits)
# fruits.insert(1,"orange")
# print(fruits)
# fruits2=['grape','bluberry']
# fruits.extend(fruits2)
# print(fruits)
# fruits.remove('banana')
# print(fruits)

# 5
# no=[5,4,8,1,3]
# no.sort()
# print("ascending",no)
# no.reverse()
# print("dec",no)
# print("dec",no[::-1])

# 6
# my_list=[1,1.5,'apple',[1,2,3],True]
# print(my_list[-1])

# 8
# fruits=['apple','banana','cherry']
# print(fruits.count('apple'))

# 9
# no=[5,4,8,1,3]
# print(no[::-1])

# 10
# a=[1,2,3]
# b=a.copy()
# b.append(10)
# print(b)
# print(a)

# 12
# no=[5,4,8,1,3]
# a=map()

# 16
# no=[5,4,8,1,3]
# print("minimum",min(no))
# print("maximum",max(no))

# 18
# fruits=['apple','banana','cherry']
# print(len(fruits))

# 19
# no=[5,4,8,1,3]
# print(5+4+8+1+3)

# 20
# fruits=['apple','banana','cherry']
# fruits[1]='grap'
# print(fruits)

