a='Shdb hzjx ujuzxn '
print("count",a.count('p'))
print("isdigit",a.isdigit())
print("islower",a.islower())
print("isupper",a.isupper())
print("split",a.split())
print("swapcase",a.swapcase())
print("upper",a.upper())
print("lower",a.lower())
print("capitalize",a.capitalize())
print("casefold",a.casefold())
print("istitle",a.istitle())
print("isnumeric",a.isnumeric())










