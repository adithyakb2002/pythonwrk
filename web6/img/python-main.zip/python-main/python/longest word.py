a=str(input("enter a string"))
z=a.split(' ')
b=[]
for i in a:
    b.append(len(i))
# print(a[b.index(max(b))])



    
