a=int(input('enter a number'))
for i in range(a):
    print(i*'*')
for i in range(a,0,-1):
    print(i*'*')
