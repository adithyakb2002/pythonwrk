a=[2,9,3,8,4,1,7,5]

b=(max(a))
c=(min(a))

a.remove(b)
a.remove(c)
print(max(a))
print(min(a))

