# a=int(input('enter a number'))
a=[5,4,3,6,7,3,2,1]
for i in  a:

    print(i*'*')
# print('='*10)