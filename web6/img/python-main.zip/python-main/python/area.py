l=int(input("enter l"))
b=int(input("enter b"))
a=(l*b)
print('area=',a)
p=(2*l*b)
print('perimeter=',p)

