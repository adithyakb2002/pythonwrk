# a=str(input('enter a string'))
# b=['a','e','i','o','u']
# if a in b:
#     print(" vowels")
# else:
#     print("consonant")

# 3
# a=int(input('enter a no'))
# b=int(input('enter a no '))
# if a>b:
#     print(a," is largest")
# elif b>a:
#     print(b," is largest")
# else:
#      print("a and b are equal")

# 4
# a=int(input('enter your age'))
# if a<18:
#     print("minor")
# elif a<64:
#         print("adult")
# else:
#     print("senior citizon")

# 7
# a=int(input('enter  1st number'))
# b=int(input('enter  2nd number'))
# sum=a+b   
# if sum in range(0,100,2):
#     print('even')
# else:
#         print('odd')

# 6
# a=int(input('enter first number'))
# b=int(input('enter second number'))
# c=a/b
# if a/b==0:
#     print("divisible")
# else:
#     print("not a divisible")



