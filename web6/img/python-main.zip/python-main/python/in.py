# a='vijay'
# print(a)
# print(type(a))
# a=10
# print(a)
# print(type(a))
# a=10.1
# print(a)
# print(type(a))
# a=10+2j
# print(a)
# print(type(a))
# a=[1,2,3,10]
# print(a)
# print(type(a))
# a=(1,2,3,10)
# print(a)
# print(type(a))
# a=range(100)
# print(a)
# print(type(a))
# a={1,1,2,2,3,4,4,5}
# print(a)
# print(type(a))
# a={'name':'an'}
# print(a)
# print(type(a))
# a=True                  
# print(a)
# print(type(a))
# triangle
a=int(input('enter side 1'))
b=int(input('enter side 2'))
c=int(input('enter side 3'))
if a==b==c:
    print('equilateral')
elif a!=b!=c:
    print('scalene')
else:
    print('isosceles')


