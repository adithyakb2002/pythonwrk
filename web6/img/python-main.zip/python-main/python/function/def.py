# def myfunction():
#     print("hello")
# myfunction()

def myfunction(a,b):
    print("hello",a)
    print("your age:",b)
name=input("enter your name")
age=int(input("enter your age"))
myfunction(name,age)
    