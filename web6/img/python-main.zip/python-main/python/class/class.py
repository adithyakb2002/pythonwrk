class What:
    def wha(x):
        print("PPP")
class Ex(What):
    def em(x):
                print("em()")
class Mn:
      def po(x):
            print("po()")
class Qw(Ex,Mn):
      def er(x):
          print("er()")

a=Qw()
a.wha()
a.em()
a.er()
a.po()


