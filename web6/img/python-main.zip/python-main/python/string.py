# palindrome
a=input("enter a string")
if a==a[::-1]:
    print("palindrome")
else:
    print("string is not palindrome")
  