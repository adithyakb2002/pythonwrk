a=[1,2,4,3,4,6,7,8,4,3,8,9]
# a.insert(2,11)
# a.append(10)
# b=[10,2]
# a.extend(b)
# a.remove(10)
# a.pop(3)
# a.clear()
a[1:8]=[10,5]
print(a)
