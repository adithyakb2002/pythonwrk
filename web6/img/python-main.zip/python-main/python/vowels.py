# b='vijay'
# a=[a,e,i,o,u]
# if a=b:
#     p
# for i in a:
#     print
# c='vijay'
# b=["a","e","l","o","u"]
# if c==b:
#     for i in c:
#         print()
a="vijay"
b=[]
for i in a:
   a.append(i)
print(a)    