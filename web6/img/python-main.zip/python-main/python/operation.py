a=10
b=30
print("a+b=",a+b)
print("a-b=",a-b)
print("a*b=",a*b)
print("a/b=",a/b)
print("a % b=",a%b)
print("a**b=",a**b)
print("a//b=",a//b)
print("addition",a+b, "substraction",a-b, )