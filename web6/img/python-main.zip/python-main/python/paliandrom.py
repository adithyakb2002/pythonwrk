# a="convert a sentance little case.lorem ipsumgj ."
# # b=a.split()
# print(a.capitalize())
# a="lorem"
# if a==a[::-1]:
#     print("paliandrome")
# else:
#     print("not ")
# a='string'
# b='str'

# if b in a:
#     print('substring')
# else:
#     print("not a substring")