
a=int(input('enter 1st number'))
b=int(input('enter 2nd number'))
print("before")
print(a)
print(b)
 
a,b=b,a


print("after")
print(a)
print(b)