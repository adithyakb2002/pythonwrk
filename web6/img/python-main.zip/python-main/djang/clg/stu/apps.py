from django.apps import AppConfig


class StuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stu'
